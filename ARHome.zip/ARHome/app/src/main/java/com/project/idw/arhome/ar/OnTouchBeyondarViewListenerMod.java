package com.project.idw.arhome.ar;

import android.view.MotionEvent;

/**
 * Created by Amal Krishnan on 23-05-2017.
 */

public interface OnTouchBeyondarViewListenerMod {
    void onTouchBeyondarView(MotionEvent var1, ArBeyondarGLSurfaceView var2);
}

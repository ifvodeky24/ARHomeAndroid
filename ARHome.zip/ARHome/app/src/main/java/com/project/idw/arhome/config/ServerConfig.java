package com.project.idw.arhome.config;

public class ServerConfig {
//    public static final String ENDPOINT="http://192.168.43.220"; //wifi hape
    public static final String ENDPOINT="http://arslyn.com";
//    public static final String SERVER= ENDPOINT+"/ar_home/ar_home/api/v1/";
//    public static final String PROFIL_IMAGE= ENDPOINT+"/ar_home/ar_home/web/files/images/";
//    public static final String KONTRAKAN_IMAGE= ENDPOINT+ "/ar_home/ar_home/web/files/kontrakan/";
//    public static final String KOS_IMAGE= ENDPOINT+"/ar_home/ar_home/web/files/kos/";
//    public static final String UPLOAD_FOTO_KOS = ENDPOINT+"/ar_home/ar_home/api/upload/upload-foto-kos.php";
//    public static final String UPLOAD_FOTO_KONTRAKAN = ENDPOINT+"/ar_home/ar_home/api/upload/upload-foto-kontrakan.php";
//    public static final String UPLOAD_FOTO_PEMILIK = ENDPOINT+"/ar_home/ar_home/api/upload/upload-foto-pemilik.php";
//    public static final String UPLOAD_FOTO_PENGGUNA = ENDPOINT+"/ar_home/ar_home/api/upload/upload-foto-pengguna.php";
//    public static final String UPLOAD_FOTO_KOS_TEST = ENDPOINT+"/ar_home/ar_home/api/upload/upload-foto-kos-test.php";
//    public static final String UPLOAD_FOTO_KONTRAKAN_TEST = ENDPOINT+"/ar_home/ar_home/api/upload/upload-foto-kontrakan-test.php";
//    public static final String UPDATE_FOTO_KONTRAKAN_TEST = ENDPOINT+"/ar_home/ar_home/api/upload/update-foto-kontrakan-test.php";
//    public static final String UPDATE_FOTO_KOS_TEST = ENDPOINT+"/ar_home/ar_home/api/upload/update-foto-kos-test.php";

    public static final String SERVER= ENDPOINT+"/ar_home/api/v1/";
    public static final String PROFIL_IMAGE= ENDPOINT+"/ar_home/web/files/images/";
    public static final String KONTRAKAN_IMAGE= ENDPOINT+ "/ar_home/web/files/kontrakan/";
    public static final String KOS_IMAGE= ENDPOINT+"/ar_home/web/files/kos/";
    public static final String UPLOAD_FOTO_KOS = ENDPOINT+"/ar_home/api/upload/upload-foto-kos.php";
    public static final String UPLOAD_FOTO_KONTRAKAN = ENDPOINT+"/ar_home/api/upload/upload-foto-kontrakan.php";
    public static final String UPLOAD_FOTO_PEMILIK = ENDPOINT+"/ar_home/api/upload/upload-foto-pemilik.php";
    public static final String UPLOAD_FOTO_PENGGUNA = ENDPOINT+"/ar_home/api/upload/upload-foto-pengguna.php";
    public static final String UPLOAD_FOTO_KOS_TEST = ENDPOINT+"/ar_home/api/upload/upload-foto-kos-test.php";
    public static final String UPLOAD_FOTO_KONTRAKAN_TEST = ENDPOINT+"/ar_home/api/upload/upload-foto-kontrakan-test.php";
    public static final String UPDATE_FOTO_KONTRAKAN_TEST = ENDPOINT+"/ar_home/api/upload/update-foto-kontrakan-test.php";
    public static final String UPDATE_FOTO_KOS_TEST = ENDPOINT+"/ar_home/api/upload/update-foto-kos-test.php";
}
